# UCMA-IVR-Demo

This is the source code which accompanies the blog post:

> 

Description:

> A simple IVR for Microsoft Lync / Skype for Business showing what's possible

## About Me

My name is [Tom Morgan](http://thoughtstuff.co.uk) and I [blog](http://blog.thoughtstuff.co.uk) about developing software solutions with Microsoft Lync and Skype for Business. For more code samples, see the full list at [thoughtstuff.co.uk/code](http://thoughtstuff.co.uk/code)
